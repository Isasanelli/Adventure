package com.gioco.thehuntress.type;

public enum CommandType {
    GUARDA,FOCUS, CRIPTA, PRENDI, LASCIA, MAPPA, NORD, SUD, EST, OVEST, MIRA, NASCONDITI, INVENTARIO, ESCI,
    PREMI;
}

