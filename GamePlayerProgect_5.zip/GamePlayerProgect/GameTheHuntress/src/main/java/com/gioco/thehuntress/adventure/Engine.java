
package com.gioco.thehuntress.adventure;

import com.gioco.thehuntress.minigame.TicTacGame;

import java.io.IOException;
import java.util.Scanner;
import com.gioco.thehuntress.eventi.Eventi;

/**
 *
 * @author Margari Chiara
 * @author Ricciardi Raffaella
 * @author Sasanelli Ilenia
 */
public class Engine {



    public  void avvio() throws IOException {

        Scanner io = new Scanner(System.in);
        Grafica menu = new Grafica();
        menu.writeMenu();

        String input ;

        do {
             input = io.nextLine();
            input=input.toLowerCase();

            switch (input) {
                case "nuova partita":
                    menu.writeIntro();
                    break;
                case "regole del gioco":
                    Eventi.leggiRegole();
                    break;
                case "comandi":
                    Eventi.leggiComandi();
                    break;
                case "esci":
                    break;

                default: System.out.println("Scelta non valida. Riprova");
                break;

            }//end of game
        } while (!input.equals("esci"));
        System.out.println("Il gioco e' bello quando dura poco."
                + " PACE E AMORE "
                + " Un saluto da :"
                + " Chiara Margari, "
                + " Ricciardi Raffaella e"
                + " Sasanelli Ilenia");
        }

    public static void main(String[] args) throws IOException {
       //new Engine().avvio();
        new TicTacGame().computer_play();


    }

    }
